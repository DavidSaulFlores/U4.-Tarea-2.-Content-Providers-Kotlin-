package mx.edu.ittepic.ladm_u4_tarea2_floresmedranodavidsaul

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var examples = arrayOf("ejemplo 1", "ejemplo 2")
    var mySpinner: Spinner? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mySpinner = this.spn1
        // mySpinner.setOnItemSelectedListener(this)


        val s1 = ArrayAdapter(this, android.R.layout.simple_list_item_1, examples)


        mySpinner!!.setAdapter(s1)

        btnBoton.setOnClickListener {

            if (mySpinner!!.selectedItem.equals("ejemplo 1")) {
                // Toast.makeText(this, "hola", Toast.LENGTH_LONG).show()

                var ejemplo1 = Intent(this, Ejemplo1::class.java)
                startActivity(ejemplo1)
            }


            if (mySpinner!!.selectedItem.equals("ejemplo 2")) {
                // Toast.makeText(this, "hola", Toast.LENGTH_LONG).show()

                var ejemplo1 = Intent(this, Main2Activity_Ejemplo2::class.java)
                startActivity(ejemplo1)
            }
        }//termina el boton========>
    }


}
